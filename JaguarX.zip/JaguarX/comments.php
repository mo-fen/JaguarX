<?php function threadedComments($comments, $options) {
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';  //如果是文章作者的评论添加 .comment-by-author 样式
        } else {
            $commentClass .= ' comment-by-user';  //如果是评论作者的添加 .comment-by-user 样式
        }
    } 
    $commentLevelClass = $comments->_levels > 0 ? ' comment-child' : ' comment-parent';  //评论层数大于0为子级，否则是父级
	$depth = $comments->levels +1;
?>
	<?php //判断邮箱类型选取头像地址
		$email = $comments->mail;
	if(preg_match('|^[1-9]\d{4,10}@qq\.com$|i',$email)){
		$qqnumber = explode("@",$email);
		$avatar = '//q.qlogo.cn/g?b=qq&nk=' . $qqnumber[0]. '&s=100';
		$avatar2x = '//q.qlogo.cn/g?b=qq&nk=' . $qqnumber[0]. '&s=160';
	 }else{
		$avatar = 'https://gravatar.loli.net/avatar/' . md5(strtolower($comments->mail)) . '?s=80&r=X&d=mm';
		$avatar2x = 'https://gravatar.loli.net/avatar/' . md5(strtolower($comments->mail)) . '?s=160&r=X&d=mm';
		
	}
	?>
	<li class="comment">
		<div class="comment-body comments">
			<div class ="comment-meta">
				<div class="comment-author vcard">
					<a href="<?php $comments->url(); ?>"--><img alt="<?php $comments->author(false); ?>" src="<?php echo $avatar ?>" srcset="<?php echo $avatar2x ?> 2x" class="avatar" height="50" width="50"/><b class="fn"><?php $comments->author(false); ?></b></a>
	                <a rel='nofollow' class='reply' href='<?php $comments->responseUrl(); ?>' onclick="return TypechoComment.reply('<?php $comments->theId(); ?>', <?php $comments->coid();?>);" aria-label='回复给<?php $comments->author(false); ?>'>回复</a>
			    </div>
				<div class="comment-metadata">
			        <time><?php $comments->date(''); ?></time>
			    </div>
			</div>
			<div class="comment-content">
				<p>
					<?php get_commentReply_at($comments->coid); ?>                                   <!-- 评论@ -->
					<?php $cos = preg_replace('#</?[p|P][^>]*>#','',$comments->content);echo $cos;?> <!-- 评论内容 -->
				</p>
			</div>
		</div>
		<?php if ($comments->children){ ?>
		<!-- 嵌套评论代码 -->
		<div class="children">
			<?php $comments->threadedComments($options); ?>
		</div>
		<?php } ?>
	</li>
<?php } ?>

<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<section id="comments" class="comments">
		<!-- 输出评论信息 -->
	<div class="comments-main">
		<h3 id="comments-list-title">Comments | <a ><?php $this->commentsNum(_t('NOTHING'), _t('<span class="noticom">1</span>条评论'), _t('<span class="noticom">%d</span>条评论')); ?></a></h3> 
		<div id="loading-comments"><span></span>
		</div>
		<!-- 评论内容 -->
	<div id="comments-ajax">
	<?php $this->comments()->to($comments); ?>
    <?php $comments->listComments(); ?>
	</div>
	<?php if ($comments->have()): ?>
	<?php endif; ?>
		<!--评论框-->
		<!-- 判断设置是否允许对当前文章进行评论 -->
		<?php if($this->allow('comment')): ?>
		<nav id="comments-navi"></nav>
		    <div id="respond_box">
			    <div id="<?php $this->respondId(); ?>" class="comment-respond">
				    <div class="cancel-comment-reply">
					    <?php $comments->cancelReply(); ?>
				    </div>
				    <!-- 输入表单开始 -->
				    <div id="respond-post" class="respond">
				        <div class="cancel-comment-reply">
				        </div> 
				    <h3 id="response" class="comment-reply-title">添加新评论</h3> 
				        <form method="post" action="<?php $this->commentUrl() ?>" id="comment-form" class="comment-form" role="form">
				        <?php if($this->user->hasLogin()): ?>
			<p>
				<?php _e('登录身份: '); ?>
				<a href="<?php $this->options->profileUrl(); ?>">
					<?php $this->user->screenName(); ?>
				</a>.
				<a href="<?php $this->options->logoutUrl(); ?>" title="Logout" no-pjax>
					<?php _e('退出'); ?>&raquo;</a>
			</p>
			<?php else: ?> 
				            <p> 
				                <label for="author" class="required">称呼</label> 
				                <input type="text" name="author" id="author" class="text" value="" required /> 
				            </p> 
				            <p> 
				                <label for="mail" class="required">Email</label> 
				                <input type="text" name="mail" id="mail" class="text" value="" required /> 
				            </p> 
				            <p> 
				                <label for="url">网站</label> 
				                <input type="text" name="url" id="url" class="text" placeholder="http://" value="" /> 
				            </p> 
				            <p> 
				            <?php endif; ?>
				                <label for="textarea" class="required">内容</label> <textarea rows="8" cols="50" name="text" id="comment" class="textarea" required ></textarea> 
				            </p> 
				            <p> 
				                <button type="submit" id="submit" class="submit">提交评论</button> 
				            </p> 
				       </form> 				      
				   </div> 
			  </div> 
	    </div> 
	</div>
</div>
			 <?php else: ?>
				<section class="author-profile">
					<p>该文章已经关闭评论</p>
				</section>
			<?php endif; ?>
			<div class="clear">
			</div>
</section>
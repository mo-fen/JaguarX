<footer class="site-footer clearfix u-textAlignCenter">Copyright © <?php echo date("Y");?> by <a href="<?php $this->options ->siteUrl(); ?>" target="_blank" rel="nofollow"><?php $this->options->title() ?></a> . All rights reserved.<br/>Theme is Pinghsu by <a href="https:mofeng.xyz">silentwind</a><br/>Powered by <a href="https//typecho.org">Powered by Typecho.</a></footer>
<div class="back2top"><svg class="icon" viewBox="0 0 1229 1024" xmlns:xlink="http://www.w3.org/1999/xlink" width="19.203125" height="16">
    <defs>
        <style type="text/css"></style>
    </defs>
    <path d="M955.765399 614.591058v408.726594h-682.348237V614.591058h-273.416939l614.591057-614.591058 614.591058 614.591058H955.765399z" fill="" ></path>
</svg></div> 
<script type="text/javascript">
/*打开侧栏，修改侧栏宽度，主体左跨度、背景透明度*/
    function openNav() {
        document.getElementById("mySidenav").style.width = "60%";
	    //document.getElementById("main").style.marginLeft = "60%";
	    //document.getElementById("mainheader").style.marginLeft = "70%";
    	document.body.style.backgroundColor = "rgba(255,255,255,0.1)";
    }
    /*关闭侧栏，恢复原始侧栏宽度，主体左跨度、背景透明度*/
    function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
	//document.getElementById("main").style.marginLeft= "0";
	//document.getElementById("mainheader").style.marginLeft = "0";
	document.body.style.backgroundColor = "white";
    }
</script>
</body> 
</html> 